package com.example.newsapp.navigation

interface ArticleNavigator {
    fun openArticleDetail(articleId: Int)
}
