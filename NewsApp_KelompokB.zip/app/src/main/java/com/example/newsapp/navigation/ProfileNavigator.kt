﻿package com.example.newsapp.navigation

interface ProfileNavigator {
    fun openSettings()
    fun openEditProfile()
}
